"""Beginning"""
#Name:John Hopkins
#Class:SDEV300
#Project 6
#Date:April 27, 2021
#Professor: Zack Fair

from datetime import date
from flask import Flask
from flask import render_template



#Activating the Flask command
#Also setting up our folders to put html's and css file in
APP = Flask(__name__, template_folder='templates', static_folder='static')
#Setting up html files
@APP.route("/")
@APP.route("/Home")
def startup():
    """STARTUP"""
    timedate = date.today()
    return render_template("Home.html", today=timedate)
#Two html files defined
# The first html lineup defined
@APP.route("/lineup")
def lineup():
    """lineup"""
    return render_template("lineup.html")
# The second html position defined
@APP.route("/positions")
def positions():
    """positions"""
    return render_template("positions.html")
#Allow the process to run and assign port number to website
if __name__ == '__main__':
    APP.run(host='127.0.0.1', port=3001)
    